/*globals OnDemandClient:false*/

describe('OnDemandClient', function () {

    'use strict';

    it('passes a very complicated test', function () {
        expect(true).toBeTruthy();
    });
});